const Transaction = require('../models/Transaction');
const Account = require('../models/Account');

// @desc    Get all transactions
// @route   GET /api/transactions
// @access  Public
exports.getTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find().sort({ date: -1 });
    
    // Add isEditable to each transaction
    const transactionsWithEditable = transactions.map(t => {
      const obj = t.toObject();
      obj.isEditable = t.isEditable;
      return obj;
    });

    res.status(200).json({
      success: true,
      count: transactions.length,
      data: transactionsWithEditable
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get single transaction
// @route   GET /api/transactions/:id
// @access  Public
exports.getTransaction = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({
        success: false,
        error: 'Transaction not found'
      });
    }

    const obj = transaction.toObject();
    obj.isEditable = transaction.isEditable;

    res.status(200).json({
      success: true,
      data: obj
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Create new transaction
// @route   POST /api/transactions
// @access  Public
exports.createTransaction = async (req, res) => {
  try {
    const { type, amount, category, division, description, date, accountId } = req.body;

    // Create transaction
    const transaction = await Transaction.create({
      type,
      amount,
      category,
      division,
      description,
      date: date || new Date(),
      accountId
    });

    // Update account balance
    const account = await Account.findById(accountId);
    if (account) {
      if (type === 'income') {
        account.balance += amount;
      } else {
        account.balance -= amount;
      }
      await account.save();
    }

    const obj = transaction.toObject();
    obj.isEditable = transaction.isEditable;

    res.status(201).json({
      success: true,
      data: obj
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Update transaction
// @route   PUT /api/transactions/:id
// @access  Public
exports.updateTransaction = async (req, res) => {
  try {
    let transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({
        success: false,
        error: 'Transaction not found'
      });
    }

    // Check if transaction is still editable (within 12 hours)
    if (!transaction.isEditable) {
      return res.status(403).json({
        success: false,
        error: 'Transaction can only be edited within 12 hours of creation'
      });
    }

    const { type, amount, category, division, description, date, accountId } = req.body;

    // Reverse the old transaction's effect on account
    const oldAccount = await Account.findById(transaction.accountId);
    if (oldAccount) {
      if (transaction.type === 'income') {
        oldAccount.balance -= transaction.amount;
      } else {
        oldAccount.balance += transaction.amount;
      }
      await oldAccount.save();
    }

    // Update transaction
    transaction = await Transaction.findByIdAndUpdate(
      req.params.id,
      { type, amount, category, division, description, date, accountId },
      { new: true, runValidators: true }
    );

    // Apply new transaction's effect on account
    const newAccount = await Account.findById(accountId);
    if (newAccount) {
      if (type === 'income') {
        newAccount.balance += amount;
      } else {
        newAccount.balance -= amount;
      }
      await newAccount.save();
    }

    const obj = transaction.toObject();
    obj.isEditable = transaction.isEditable;

    res.status(200).json({
      success: true,
      data: obj
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Delete transaction
// @route   DELETE /api/transactions/:id
// @access  Public
exports.deleteTransaction = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id);

    if (!transaction) {
      return res.status(404).json({
        success: false,
        error: 'Transaction not found'
      });
    }

    // Reverse the transaction's effect on account
    const account = await Account.findById(transaction.accountId);
    if (account) {
      if (transaction.type === 'income') {
        account.balance -= transaction.amount;
      } else {
        account.balance += transaction.amount;
      }
      await account.save();
    }

    await transaction.deleteOne();

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Filter transactions
// @route   GET /api/transactions/filter
// @access  Public
exports.filterTransactions = async (req, res) => {
  try {
    const { type, category, division, accountId, startDate, endDate } = req.query;

    let query = {};

    if (type && type !== 'all') {
      query.type = type;
    }

    if (category && category !== 'all') {
      query.category = category;
    }

    if (division && division !== 'all') {
      query.division = division;
    }

    if (accountId && accountId !== 'all') {
      query.accountId = accountId;
    }

    if (startDate || endDate) {
      query.date = {};
      if (startDate) {
        query.date.$gte = new Date(startDate);
      }
      if (endDate) {
        query.date.$lte = new Date(endDate + 'T23:59:59.999Z');
      }
    }

    const transactions = await Transaction.find(query).sort({ date: -1 });

    const transactionsWithEditable = transactions.map(t => {
      const obj = t.toObject();
      obj.isEditable = t.isEditable;
      return obj;
    });

    res.status(200).json({
      success: true,
      count: transactions.length,
      data: transactionsWithEditable
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get category summary
// @route   GET /api/transactions/summary
// @access  Public
exports.getCategorySummary = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;

    let matchStage = {};

    if (startDate || endDate) {
      matchStage.date = {};
      if (startDate) {
        matchStage.date.$gte = new Date(startDate);
      }
      if (endDate) {
        matchStage.date.$lte = new Date(endDate + 'T23:59:59.999Z');
      }
    }

    const summary = await Transaction.aggregate([
      { $match: matchStage },
      {
        $group: {
          _id: { category: '$category', type: '$type' },
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      },
      {
        $group: {
          _id: '$_id.category',
          income: {
            $sum: { $cond: [{ $eq: ['$_id.type', 'income'] }, '$total', 0] }
          },
          expense: {
            $sum: { $cond: [{ $eq: ['$_id.type', 'expense'] }, '$total', 0] }
          },
          incomeCount: {
            $sum: { $cond: [{ $eq: ['$_id.type', 'income'] }, '$count', 0] }
          },
          expenseCount: {
            $sum: { $cond: [{ $eq: ['$_id.type', 'expense'] }, '$count', 0] }
          }
        }
      },
      {
        $project: {
          category: '$_id',
          income: 1,
          expense: 1,
          net: { $subtract: ['$income', '$expense'] },
          totalTransactions: { $add: ['$incomeCount', '$expenseCount'] }
        }
      },
      { $sort: { expense: -1 } }
    ]);

    res.status(200).json({
      success: true,
      data: summary
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get dashboard stats
// @route   GET /api/transactions/stats
// @access  Public
exports.getDashboardStats = async (req, res) => {
  try {
    const { period } = req.query; // weekly, monthly, yearly

    let startDate = new Date();
    const endDate = new Date();

    switch (period) {
      case 'weekly':
        startDate.setDate(startDate.getDate() - 7);
        break;
      case 'monthly':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case 'yearly':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      default:
        startDate.setMonth(startDate.getMonth() - 1);
    }

    const stats = await Transaction.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $group: {
          _id: '$type',
          total: { $sum: '$amount' }
        }
      }
    ]);

    const income = stats.find(s => s._id === 'income')?.total || 0;
    const expense = stats.find(s => s._id === 'expense')?.total || 0;

    // Get category breakdown for expenses
    const categoryBreakdown = await Transaction.aggregate([
      {
        $match: {
          date: { $gte: startDate, $lte: endDate },
          type: 'expense'
        }
      },
      {
        $group: {
          _id: '$category',
          total: { $sum: '$amount' }
        }
      },
      { $sort: { total: -1 } }
    ]);

    res.status(200).json({
      success: true,
      data: {
        income,
        expense,
        netBalance: income - expense,
        categoryBreakdown: categoryBreakdown.map(c => ({
          category: c._id,
          amount: c.total
        }))
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};
