const Account = require('../models/Account');

// Default accounts configuration
const defaultAccounts = [
  { _id: 'cash', name: 'Cash', balance: 5000, icon: 'Wallet', color: 'bg-green-500' },
  { _id: 'bank', name: 'Bank Account', balance: 25000, icon: 'Building2', color: 'bg-blue-500' },
  { _id: 'credit', name: 'Credit Card', balance: 0, icon: 'CreditCard', color: 'bg-purple-500' },
  { _id: 'savings', name: 'Savings', balance: 50000, icon: 'PiggyBank', color: 'bg-yellow-500' }
];

// @desc    Get all accounts
// @route   GET /api/accounts
// @access  Public
exports.getAccounts = async (req, res) => {
  try {
    let accounts = await Account.find().sort({ name: 1 });

    // If no accounts exist, create default accounts
    if (accounts.length === 0) {
      accounts = await Account.insertMany(defaultAccounts);
    }

    res.status(200).json({
      success: true,
      count: accounts.length,
      data: accounts
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get single account
// @route   GET /api/accounts/:id
// @access  Public
exports.getAccount = async (req, res) => {
  try {
    const account = await Account.findById(req.params.id);

    if (!account) {
      return res.status(404).json({
        success: false,
        error: 'Account not found'
      });
    }

    res.status(200).json({
      success: true,
      data: account
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Create new account
// @route   POST /api/accounts
// @access  Public
exports.createAccount = async (req, res) => {
  try {
    const { _id, name, balance, icon, color } = req.body;

    const account = await Account.create({
      _id,
      name,
      balance: balance || 0,
      icon: icon || 'Wallet',
      color: color || 'bg-green-500'
    });

    res.status(201).json({
      success: true,
      data: account
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        error: 'Account with this ID already exists'
      });
    }
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Update account
// @route   PUT /api/accounts/:id
// @access  Public
exports.updateAccount = async (req, res) => {
  try {
    const { name, balance, icon, color } = req.body;

    const account = await Account.findByIdAndUpdate(
      req.params.id,
      { name, balance, icon, color },
      { new: true, runValidators: true }
    );

    if (!account) {
      return res.status(404).json({
        success: false,
        error: 'Account not found'
      });
    }

    res.status(200).json({
      success: true,
      data: account
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Initialize default accounts
// @route   POST /api/accounts/init
// @access  Public
exports.initializeAccounts = async (req, res) => {
  try {
    // Check if accounts already exist
    const existingAccounts = await Account.find();
    
    if (existingAccounts.length > 0) {
      return res.status(200).json({
        success: true,
        message: 'Accounts already initialized',
        data: existingAccounts
      });
    }

    // Create default accounts
    const accounts = await Account.insertMany(defaultAccounts);

    res.status(201).json({
      success: true,
      message: 'Default accounts created successfully',
      data: accounts
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get total balance across all accounts
// @route   GET /api/accounts/total
// @access  Public
exports.getTotalBalance = async (req, res) => {
  try {
    const result = await Account.aggregate([
      {
        $group: {
          _id: null,
          totalBalance: { $sum: '$balance' }
        }
      }
    ]);

    const totalBalance = result.length > 0 ? result[0].totalBalance : 0;

    res.status(200).json({
      success: true,
      data: { totalBalance }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};
