const Transfer = require('../models/Transfer');
const Account = require('../models/Account');

// @desc    Get all transfers
// @route   GET /api/transfers
// @access  Public
exports.getTransfers = async (req, res) => {
  try {
    const transfers = await Transfer.find().sort({ date: -1 });

    res.status(200).json({
      success: true,
      count: transfers.length,
      data: transfers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get single transfer
// @route   GET /api/transfers/:id
// @access  Public
exports.getTransfer = async (req, res) => {
  try {
    const transfer = await Transfer.findById(req.params.id);

    if (!transfer) {
      return res.status(404).json({
        success: false,
        error: 'Transfer not found'
      });
    }

    res.status(200).json({
      success: true,
      data: transfer
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Create new transfer
// @route   POST /api/transfers
// @access  Public
exports.createTransfer = async (req, res) => {
  try {
    const { fromAccountId, toAccountId, amount, description, date } = req.body;

    // Validate that accounts are different
    if (fromAccountId === toAccountId) {
      return res.status(400).json({
        success: false,
        error: 'Source and destination accounts must be different'
      });
    }

    // Get source account
    const fromAccount = await Account.findById(fromAccountId);
    if (!fromAccount) {
      return res.status(404).json({
        success: false,
        error: 'Source account not found'
      });
    }

    // Get destination account
    const toAccount = await Account.findById(toAccountId);
    if (!toAccount) {
      return res.status(404).json({
        success: false,
        error: 'Destination account not found'
      });
    }

    // Check if source account has sufficient balance
    if (fromAccount.balance < amount) {
      return res.status(400).json({
        success: false,
        error: 'Insufficient balance in source account'
      });
    }

    // Create transfer record
    const transfer = await Transfer.create({
      fromAccountId,
      toAccountId,
      amount,
      description: description || `Transfer from ${fromAccount.name} to ${toAccount.name}`,
      date: date || new Date()
    });

    // Update account balances
    fromAccount.balance -= amount;
    toAccount.balance += amount;

    await fromAccount.save();
    await toAccount.save();

    res.status(201).json({
      success: true,
      data: transfer,
      accounts: {
        from: fromAccount,
        to: toAccount
      }
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        error: messages
      });
    }
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get transfers by account
// @route   GET /api/transfers/account/:accountId
// @access  Public
exports.getTransfersByAccount = async (req, res) => {
  try {
    const { accountId } = req.params;

    const transfers = await Transfer.find({
      $or: [
        { fromAccountId: accountId },
        { toAccountId: accountId }
      ]
    }).sort({ date: -1 });

    res.status(200).json({
      success: true,
      count: transfers.length,
      data: transfers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};

// @desc    Get transfers between dates
// @route   GET /api/transfers/filter
// @access  Public
exports.filterTransfers = async (req, res) => {
  try {
    const { startDate, endDate, accountId } = req.query;

    let query = {};

    if (accountId) {
      query.$or = [
        { fromAccountId: accountId },
        { toAccountId: accountId }
      ];
    }

    if (startDate || endDate) {
      query.date = {};
      if (startDate) {
        query.date.$gte = new Date(startDate);
      }
      if (endDate) {
        query.date.$lte = new Date(endDate + 'T23:59:59.999Z');
      }
    }

    const transfers = await Transfer.find(query).sort({ date: -1 });

    res.status(200).json({
      success: true,
      count: transfers.length,
      data: transfers
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error: ' + error.message
    });
  }
};
