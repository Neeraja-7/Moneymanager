const express = require('express');
const router = express.Router();
const {
  getTransactions,
  getTransaction,
  createTransaction,
  updateTransaction,
  deleteTransaction,
  filterTransactions,
  getCategorySummary,
  getDashboardStats
} = require('../controllers/transactionController');

// GET /api/transactions/filter - Filter transactions (must be before /:id)
router.get('/filter', filterTransactions);

// GET /api/transactions/summary - Get category summary
router.get('/summary', getCategorySummary);

// GET /api/transactions/stats - Get dashboard statistics
router.get('/stats', getDashboardStats);

// GET /api/transactions - Get all transactions
// POST /api/transactions - Create new transaction
router.route('/')
  .get(getTransactions)
  .post(createTransaction);

// GET /api/transactions/:id - Get single transaction
// PUT /api/transactions/:id - Update transaction
// DELETE /api/transactions/:id - Delete transaction
router.route('/:id')
  .get(getTransaction)
  .put(updateTransaction)
  .delete(deleteTransaction);

module.exports = router;
