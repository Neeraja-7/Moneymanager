const express = require('express');
const router = express.Router();
const {
  getAccounts,
  getAccount,
  createAccount,
  updateAccount,
  initializeAccounts,
  getTotalBalance
} = require('../controllers/accountController');

// POST /api/accounts/init - Initialize default accounts
router.post('/init', initializeAccounts);

// GET /api/accounts/total - Get total balance across all accounts
router.get('/total', getTotalBalance);

// GET /api/accounts - Get all accounts
// POST /api/accounts - Create new account
router.route('/')
  .get(getAccounts)
  .post(createAccount);

// GET /api/accounts/:id - Get single account
// PUT /api/accounts/:id - Update account
router.route('/:id')
  .get(getAccount)
  .put(updateAccount);

module.exports = router;
