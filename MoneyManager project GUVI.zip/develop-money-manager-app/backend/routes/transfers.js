const express = require('express');
const router = express.Router();
const {
  getTransfers,
  getTransfer,
  createTransfer,
  getTransfersByAccount,
  filterTransfers
} = require('../controllers/transferController');

// GET /api/transfers/filter - Filter transfers
router.get('/filter', filterTransfers);

// GET /api/transfers/account/:accountId - Get transfers by account
router.get('/account/:accountId', getTransfersByAccount);

// GET /api/transfers - Get all transfers
// POST /api/transfers - Create new transfer
router.route('/')
  .get(getTransfers)
  .post(createTransfer);

// GET /api/transfers/:id - Get single transfer
router.route('/:id')
  .get(getTransfer);

module.exports = router;
