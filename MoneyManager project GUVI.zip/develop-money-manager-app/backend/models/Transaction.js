const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  type: {
    type: String,
    required: [true, 'Transaction type is required'],
    enum: {
      values: ['income', 'expense'],
      message: 'Type must be either income or expense'
    }
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0.01, 'Amount must be greater than 0']
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: {
      values: [
        'fuel', 'food', 'movie', 'loan', 'medical', 'shopping',
        'transport', 'utilities', 'entertainment', 'salary',
        'freelance', 'investment', 'gift', 'other'
      ],
      message: 'Invalid category'
    }
  },
  division: {
    type: String,
    required: [true, 'Division is required'],
    enum: {
      values: ['office', 'personal'],
      message: 'Division must be either office or personal'
    }
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    trim: true,
    maxlength: [200, 'Description cannot exceed 200 characters']
  },
  date: {
    type: Date,
    required: [true, 'Date is required'],
    default: Date.now
  },
  accountId: {
    type: String,
    required: [true, 'Account ID is required'],
    enum: {
      values: ['cash', 'bank', 'credit', 'savings'],
      message: 'Invalid account ID'
    }
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual to check if transaction is editable (within 12 hours)
transactionSchema.virtual('isEditable').get(function() {
  const twelveHoursAgo = new Date(Date.now() - 12 * 60 * 60 * 1000);
  return this.createdAt > twelveHoursAgo;
});

// Index for efficient queries
transactionSchema.index({ date: -1 });
transactionSchema.index({ type: 1, date: -1 });
transactionSchema.index({ category: 1 });
transactionSchema.index({ division: 1 });
transactionSchema.index({ accountId: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
