const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema({
  _id: {
    type: String,
    required: true,
    enum: ['cash', 'bank', 'credit', 'savings']
  },
  name: {
    type: String,
    required: [true, 'Account name is required'],
    trim: true
  },
  balance: {
    type: Number,
    required: true,
    default: 0
  },
  icon: {
    type: String,
    default: 'Wallet'
  },
  color: {
    type: String,
    default: 'bg-green-500'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Account', accountSchema);
