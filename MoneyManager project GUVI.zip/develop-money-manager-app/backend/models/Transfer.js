const mongoose = require('mongoose');

const transferSchema = new mongoose.Schema({
  fromAccountId: {
    type: String,
    required: [true, 'Source account is required'],
    enum: {
      values: ['cash', 'bank', 'credit', 'savings'],
      message: 'Invalid source account'
    }
  },
  toAccountId: {
    type: String,
    required: [true, 'Destination account is required'],
    enum: {
      values: ['cash', 'bank', 'credit', 'savings'],
      message: 'Invalid destination account'
    }
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0.01, 'Amount must be greater than 0']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [200, 'Description cannot exceed 200 characters'],
    default: ''
  },
  date: {
    type: Date,
    required: true,
    default: Date.now
  }
}, {
  timestamps: true
});

// Validate that source and destination accounts are different
transferSchema.pre('save', function(next) {
  if (this.fromAccountId === this.toAccountId) {
    next(new Error('Source and destination accounts must be different'));
  }
  next();
});

// Index for efficient queries
transferSchema.index({ date: -1 });
transferSchema.index({ fromAccountId: 1 });
transferSchema.index({ toAccountId: 1 });

module.exports = mongoose.model('Transfer', transferSchema);
