const mongoose = require('mongoose');
const dotenv = require('dotenv');

// Load environment variables
dotenv.config();

// Import models
const Transaction = require('./models/Transaction');
const Account = require('./models/Account');
const Transfer = require('./models/Transfer');

// Default accounts
const accounts = [
  { _id: 'cash', name: 'Cash', balance: 5000, icon: 'Wallet', color: 'bg-green-500' },
  { _id: 'bank', name: 'Bank Account', balance: 25000, icon: 'Building2', color: 'bg-blue-500' },
  { _id: 'credit', name: 'Credit Card', balance: 0, icon: 'CreditCard', color: 'bg-purple-500' },
  { _id: 'savings', name: 'Savings', balance: 50000, icon: 'PiggyBank', color: 'bg-yellow-500' }
];

// Sample transactions
const generateTransactions = () => {
  const categories = ['fuel', 'food', 'movie', 'loan', 'medical', 'shopping', 'transport', 'utilities', 'entertainment', 'salary', 'freelance', 'investment', 'gift', 'other'];
  const incomeCategories = ['salary', 'freelance', 'investment', 'gift', 'other'];
  const expenseCategories = ['fuel', 'food', 'movie', 'loan', 'medical', 'shopping', 'transport', 'utilities', 'entertainment', 'other'];
  const divisions = ['office', 'personal'];
  const accountIds = ['cash', 'bank', 'credit', 'savings'];

  const transactions = [];
  const now = new Date();

  // Generate transactions for the last 3 months
  for (let i = 0; i < 90; i++) {
    const daysAgo = Math.floor(Math.random() * 90);
    const date = new Date(now);
    date.setDate(date.getDate() - daysAgo);
    date.setHours(Math.floor(Math.random() * 24), Math.floor(Math.random() * 60), 0, 0);

    const isIncome = Math.random() > 0.7; // 30% income, 70% expense
    const type = isIncome ? 'income' : 'expense';
    const category = isIncome 
      ? incomeCategories[Math.floor(Math.random() * incomeCategories.length)]
      : expenseCategories[Math.floor(Math.random() * expenseCategories.length)];
    
    const descriptions = {
      fuel: ['Gas station fill-up', 'Petrol for car', 'Diesel refill', 'Fuel expense'],
      food: ['Grocery shopping', 'Restaurant dinner', 'Lunch at cafe', 'Coffee shop', 'Fast food'],
      movie: ['Cinema tickets', 'Movie night', 'Netflix subscription', 'Movie rental'],
      loan: ['EMI payment', 'Loan repayment', 'Interest payment'],
      medical: ['Doctor visit', 'Pharmacy', 'Medical checkup', 'Hospital bill', 'Medicine purchase'],
      shopping: ['Online shopping', 'Mall shopping', 'Clothes purchase', 'Electronics', 'Home supplies'],
      transport: ['Uber ride', 'Bus ticket', 'Train fare', 'Metro card recharge', 'Taxi fare'],
      utilities: ['Electricity bill', 'Water bill', 'Internet bill', 'Phone bill', 'Gas bill'],
      entertainment: ['Gaming', 'Concert tickets', 'Streaming subscription', 'Amusement park'],
      salary: ['Monthly salary', 'Bonus', 'Incentive'],
      freelance: ['Freelance project', 'Consulting fee', 'Side gig payment'],
      investment: ['Dividend income', 'Interest earned', 'Stock returns'],
      gift: ['Birthday gift received', 'Gift from family', 'Reward'],
      other: ['Miscellaneous', 'Other income', 'Other expense']
    };

    const descList = descriptions[category] || ['Transaction'];
    const description = descList[Math.floor(Math.random() * descList.length)];

    const amount = isIncome 
      ? Math.floor(Math.random() * 50000) + 5000  // Income: 5000 - 55000
      : Math.floor(Math.random() * 5000) + 100;   // Expense: 100 - 5100

    transactions.push({
      type,
      amount,
      category,
      division: divisions[Math.floor(Math.random() * divisions.length)],
      description,
      date,
      accountId: accountIds[Math.floor(Math.random() * accountIds.length)]
    });
  }

  return transactions;
};

// Sample transfers
const generateTransfers = () => {
  const transfers = [];
  const accountIds = ['cash', 'bank', 'credit', 'savings'];
  const now = new Date();

  for (let i = 0; i < 10; i++) {
    const daysAgo = Math.floor(Math.random() * 60);
    const date = new Date(now);
    date.setDate(date.getDate() - daysAgo);

    let fromAccountId = accountIds[Math.floor(Math.random() * accountIds.length)];
    let toAccountId = accountIds[Math.floor(Math.random() * accountIds.length)];
    
    // Ensure different accounts
    while (toAccountId === fromAccountId) {
      toAccountId = accountIds[Math.floor(Math.random() * accountIds.length)];
    }

    transfers.push({
      fromAccountId,
      toAccountId,
      amount: Math.floor(Math.random() * 10000) + 500,
      description: `Transfer from ${fromAccountId} to ${toAccountId}`,
      date
    });
  }

  return transfers;
};

// Seed database
const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('📦 Connected to MongoDB');

    // Clear existing data
    await Transaction.deleteMany({});
    await Account.deleteMany({});
    await Transfer.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Insert accounts
    await Account.insertMany(accounts);
    console.log('✅ Accounts created');

    // Insert transactions
    const transactions = generateTransactions();
    await Transaction.insertMany(transactions);
    console.log(`✅ ${transactions.length} transactions created`);

    // Insert transfers
    const transfers = generateTransfers();
    await Transfer.insertMany(transfers);
    console.log(`✅ ${transfers.length} transfers created`);

    console.log('\n🎉 Database seeded successfully!');
    
    // Disconnect
    await mongoose.disconnect();
    console.log('📤 Disconnected from MongoDB');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error.message);
    process.exit(1);
  }
};

// Run seeder
seedDatabase();
