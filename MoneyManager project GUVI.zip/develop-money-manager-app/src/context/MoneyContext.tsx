import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Transaction, Transfer, Account, Category, FilterState, ViewPeriod } from '../types';
import { defaultCategories, defaultAccounts, sampleTransactions, sampleTransfers } from '../data/initialData';
import { generateId } from '../utils/helpers';

interface MoneyContextType {
  transactions: Transaction[];
  transfers: Transfer[];
  accounts: Account[];
  categories: Category[];
  filter: FilterState;
  viewPeriod: ViewPeriod;
  selectedDate: Date;
  isLoading: boolean;
  isApiConnected: boolean;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  addTransfer: (transfer: Omit<Transfer, 'id' | 'createdAt'>) => void;
  updateAccount: (id: string, updates: Partial<Account>) => void;
  setFilter: (filter: Partial<FilterState>) => void;
  resetFilter: () => void;
  setViewPeriod: (period: ViewPeriod) => void;
  setSelectedDate: (date: Date) => void;
  refreshData: () => Promise<void>;
}

const defaultFilter: FilterState = {
  type: 'all',
  division: 'all',
  category: '',
  startDate: '',
  endDate: '',
  accountId: '',
};

const MoneyContext = createContext<MoneyContextType | undefined>(undefined);

const STORAGE_KEYS = {
  transactions: 'money_manager_transactions',
  transfers: 'money_manager_transfers',
  accounts: 'money_manager_accounts',
};

const API_BASE_URL = 'http://localhost:5000/api';

// Helper function for API calls
async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const defaultOptions: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
    },
  };

  const response = await fetch(url, { ...defaultOptions, ...options });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'API request failed');
  }

  return data;
}

export function MoneyProvider({ children }: { children: ReactNode }) {
  const [isApiConnected, setIsApiConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.transactions);
    return stored ? JSON.parse(stored) : sampleTransactions;
  });

  const [transfers, setTransfers] = useState<Transfer[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.transfers);
    return stored ? JSON.parse(stored) : sampleTransfers;
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const stored = localStorage.getItem(STORAGE_KEYS.accounts);
    return stored ? JSON.parse(stored) : defaultAccounts;
  });

  const [categories] = useState<Category[]>(defaultCategories);
  const [filter, setFilterState] = useState<FilterState>(defaultFilter);
  const [viewPeriod, setViewPeriod] = useState<ViewPeriod>('monthly');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  // Check API connection and load data
  const checkApiConnection = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/health`, { 
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        setIsApiConnected(true);
        return true;
      }
      return false;
    } catch {
      setIsApiConnected(false);
      return false;
    }
  }, []);

  // Fetch data from API
  const fetchFromApi = useCallback(async () => {
    try {
      // Fetch transactions
      const transRes = await apiCall<{ success: boolean; data: Transaction[] }>('/transactions');
      if (transRes.success && transRes.data) {
        const mappedTransactions = transRes.data.map(t => ({
          ...t,
          id: t.id || (t as unknown as { _id: string })._id,
        }));
        setTransactions(mappedTransactions);
      }

      // Fetch accounts
      const accRes = await apiCall<{ success: boolean; data: Account[] }>('/accounts');
      if (accRes.success && accRes.data) {
        const mappedAccounts = accRes.data.map(a => ({
          ...a,
          id: a.id || a._id || (a as unknown as { _id: string })._id,
        }));
        setAccounts(mappedAccounts);
      }

      // Fetch transfers
      const transferRes = await apiCall<{ success: boolean; data: Transfer[] }>('/transfers');
      if (transferRes.success && transferRes.data) {
        const mappedTransfers = transferRes.data.map(t => ({
          ...t,
          id: t.id || (t as unknown as { _id: string })._id,
        }));
        setTransfers(mappedTransfers);
      }
    } catch (error) {
      console.error('Error fetching from API:', error);
    }
  }, []);

  // Refresh data from API
  const refreshData = useCallback(async () => {
    setIsLoading(true);
    const connected = await checkApiConnection();
    if (connected) {
      await fetchFromApi();
    }
    setIsLoading(false);
  }, [checkApiConnection, fetchFromApi]);

  // Initial load - check API and fetch data
  useEffect(() => {
    const initializeData = async () => {
      setIsLoading(true);
      const connected = await checkApiConnection();
      
      if (connected) {
        console.log('✅ Connected to MongoDB backend');
        await fetchFromApi();
      } else {
        console.log('📦 Using localStorage (backend not available)');
      }
      
      setIsLoading(false);
    };

    initializeData();
  }, [checkApiConnection, fetchFromApi]);

  // Save to localStorage when data changes (fallback)
  useEffect(() => {
    if (!isApiConnected) {
      localStorage.setItem(STORAGE_KEYS.transactions, JSON.stringify(transactions));
    }
  }, [transactions, isApiConnected]);

  useEffect(() => {
    if (!isApiConnected) {
      localStorage.setItem(STORAGE_KEYS.transfers, JSON.stringify(transfers));
    }
  }, [transfers, isApiConnected]);

  useEffect(() => {
    if (!isApiConnected) {
      localStorage.setItem(STORAGE_KEYS.accounts, JSON.stringify(accounts));
    }
  }, [accounts, isApiConnected]);

  const addTransaction = async (transaction: Omit<Transaction, 'id' | 'createdAt'>) => {
    if (isApiConnected) {
      try {
        const response = await apiCall<{ success: boolean; data: Transaction }>('/transactions', {
          method: 'POST',
          body: JSON.stringify(transaction),
        });
        
        if (response.success && response.data) {
          const newTransaction = {
            ...response.data,
            id: response.data.id || (response.data as unknown as { _id: string })._id,
          };
          setTransactions((prev) => [newTransaction, ...prev]);
          
          // Refresh accounts to get updated balances
          await fetchFromApi();
        }
      } catch (error) {
        console.error('Error adding transaction:', error);
      }
    } else {
      // Fallback to localStorage
      const newTransaction: Transaction = {
        ...transaction,
        id: generateId(),
        createdAt: new Date().toISOString(),
      };
      setTransactions((prev) => [newTransaction, ...prev]);

      // Update account balance
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === transaction.accountId) {
            const change = transaction.type === 'income' ? transaction.amount : -transaction.amount;
            return { ...acc, balance: acc.balance + change };
          }
          return acc;
        })
      );
    }
  };

  const updateTransaction = async (id: string, updates: Partial<Transaction>) => {
    if (isApiConnected) {
      try {
        const response = await apiCall<{ success: boolean; data: Transaction }>(`/transactions/${id}`, {
          method: 'PUT',
          body: JSON.stringify(updates),
        });
        
        if (response.success && response.data) {
          const updatedTransaction = {
            ...response.data,
            id: response.data.id || (response.data as unknown as { _id: string })._id,
          };
          setTransactions((prev) =>
            prev.map((t) => (t.id === id ? updatedTransaction : t))
          );
          
          // Refresh accounts
          await fetchFromApi();
        }
      } catch (error) {
        console.error('Error updating transaction:', error);
        throw error;
      }
    } else {
      setTransactions((prev) =>
        prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
      );
    }
  };

  const deleteTransaction = async (id: string) => {
    if (isApiConnected) {
      try {
        await apiCall<{ success: boolean }>(`/transactions/${id}`, {
          method: 'DELETE',
        });
        
        setTransactions((prev) => prev.filter((t) => t.id !== id));
        
        // Refresh accounts
        await fetchFromApi();
      } catch (error) {
        console.error('Error deleting transaction:', error);
      }
    } else {
      const transaction = transactions.find((t) => t.id === id);
      if (transaction) {
        setAccounts((prev) =>
          prev.map((acc) => {
            if (acc.id === transaction.accountId) {
              const change = transaction.type === 'income' ? -transaction.amount : transaction.amount;
              return { ...acc, balance: acc.balance + change };
            }
            return acc;
          })
        );
      }
      setTransactions((prev) => prev.filter((t) => t.id !== id));
    }
  };

  const addTransfer = async (transfer: Omit<Transfer, 'id' | 'createdAt'>) => {
    if (isApiConnected) {
      try {
        const response = await apiCall<{ success: boolean; data: Transfer }>('/transfers', {
          method: 'POST',
          body: JSON.stringify(transfer),
        });
        
        if (response.success && response.data) {
          const newTransfer = {
            ...response.data,
            id: response.data.id || (response.data as unknown as { _id: string })._id,
          };
          setTransfers((prev) => [newTransfer, ...prev]);
          
          // Refresh accounts
          await fetchFromApi();
        }
      } catch (error) {
        console.error('Error adding transfer:', error);
        throw error;
      }
    } else {
      const newTransfer: Transfer = {
        ...transfer,
        id: generateId(),
        createdAt: new Date().toISOString(),
      };
      setTransfers((prev) => [newTransfer, ...prev]);

      // Update account balances
      setAccounts((prev) =>
        prev.map((acc) => {
          if (acc.id === transfer.fromAccountId) {
            return { ...acc, balance: acc.balance - transfer.amount };
          }
          if (acc.id === transfer.toAccountId) {
            return { ...acc, balance: acc.balance + transfer.amount };
          }
          return acc;
        })
      );
    }
  };

  const updateAccount = (id: string, updates: Partial<Account>) => {
    setAccounts((prev) =>
      prev.map((acc) => (acc.id === id ? { ...acc, ...updates } : acc))
    );
  };

  const setFilter = (newFilter: Partial<FilterState>) => {
    setFilterState((prev) => ({ ...prev, ...newFilter }));
  };

  const resetFilter = () => {
    setFilterState(defaultFilter);
  };

  return (
    <MoneyContext.Provider
      value={{
        transactions,
        transfers,
        accounts,
        categories,
        filter,
        viewPeriod,
        selectedDate,
        isLoading,
        isApiConnected,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addTransfer,
        updateAccount,
        setFilter,
        resetFilter,
        setViewPeriod,
        setSelectedDate,
        refreshData,
      }}
    >
      {children}
    </MoneyContext.Provider>
  );
}

export function useMoneyContext() {
  const context = useContext(MoneyContext);
  if (context === undefined) {
    throw new Error('useMoneyContext must be used within a MoneyProvider');
  }
  return context;
}
