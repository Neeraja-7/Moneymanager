import { Category, Account, Transaction, Transfer } from '../types';

export const defaultCategories: Category[] = [
  { id: 'fuel', name: 'Fuel', icon: '⛽', color: '#f97316' },
  { id: 'food', name: 'Food', icon: '🍔', color: '#ef4444' },
  { id: 'movie', name: 'Movie', icon: '🎬', color: '#8b5cf6' },
  { id: 'loan', name: 'Loan', icon: '💳', color: '#3b82f6' },
  { id: 'medical', name: 'Medical', icon: '🏥', color: '#10b981' },
  { id: 'shopping', name: 'Shopping', icon: '🛒', color: '#ec4899' },
  { id: 'transport', name: 'Transport', icon: '🚗', color: '#6366f1' },
  { id: 'utilities', name: 'Utilities', icon: '💡', color: '#f59e0b' },
  { id: 'entertainment', name: 'Entertainment', icon: '🎮', color: '#14b8a6' },
  { id: 'salary', name: 'Salary', icon: '💰', color: '#22c55e' },
  { id: 'freelance', name: 'Freelance', icon: '💻', color: '#0ea5e9' },
  { id: 'investment', name: 'Investment', icon: '📈', color: '#a855f7' },
  { id: 'gift', name: 'Gift', icon: '🎁', color: '#f43f5e' },
  { id: 'other', name: 'Other', icon: '📋', color: '#64748b' },
];

export const defaultAccounts: Account[] = [
  { id: 'cash', name: 'Cash', balance: 5000, color: '#22c55e' },
  { id: 'bank', name: 'Bank Account', balance: 25000, color: '#3b82f6' },
  { id: 'credit', name: 'Credit Card', balance: -2500, color: '#ef4444' },
  { id: 'savings', name: 'Savings', balance: 50000, color: '#8b5cf6' },
];

// Generate sample transactions for the last 3 months
const generateSampleTransactions = (): Transaction[] => {
  const transactions: Transaction[] = [];
  const now = new Date();
  
  const sampleData = [
    { type: 'expense', amount: 50, description: 'Petrol for car', category: 'fuel', division: 'personal', accountId: 'cash' },
    { type: 'expense', amount: 30, description: 'Office commute fuel', category: 'fuel', division: 'office', accountId: 'bank' },
    { type: 'expense', amount: 120, description: 'Grocery shopping', category: 'food', division: 'personal', accountId: 'cash' },
    { type: 'expense', amount: 45, description: 'Team lunch', category: 'food', division: 'office', accountId: 'credit' },
    { type: 'expense', amount: 25, description: 'Movie tickets', category: 'movie', division: 'personal', accountId: 'cash' },
    { type: 'income', amount: 5000, description: 'Monthly salary', category: 'salary', division: 'office', accountId: 'bank' },
    { type: 'income', amount: 800, description: 'Freelance project', category: 'freelance', division: 'personal', accountId: 'bank' },
    { type: 'expense', amount: 200, description: 'Doctor visit', category: 'medical', division: 'personal', accountId: 'bank' },
    { type: 'expense', amount: 150, description: 'New headphones', category: 'shopping', division: 'personal', accountId: 'credit' },
    { type: 'expense', amount: 80, description: 'Electricity bill', category: 'utilities', division: 'personal', accountId: 'bank' },
    { type: 'income', amount: 500, description: 'Investment returns', category: 'investment', division: 'personal', accountId: 'savings' },
    { type: 'expense', amount: 60, description: 'Bus pass', category: 'transport', division: 'office', accountId: 'cash' },
    { type: 'income', amount: 100, description: 'Birthday gift', category: 'gift', division: 'personal', accountId: 'cash' },
    { type: 'expense', amount: 35, description: 'Netflix subscription', category: 'entertainment', division: 'personal', accountId: 'bank' },
    { type: 'expense', amount: 500, description: 'Loan EMI', category: 'loan', division: 'personal', accountId: 'bank' },
  ];

  for (let i = 0; i < 90; i++) {
    const daysAgo = Math.floor(Math.random() * 90);
    const date = new Date(now);
    date.setDate(date.getDate() - daysAgo);
    date.setHours(Math.floor(Math.random() * 12) + 8, Math.floor(Math.random() * 60));
    
    const sample = sampleData[Math.floor(Math.random() * sampleData.length)];
    const amountVariation = sample.amount * (0.8 + Math.random() * 0.4);
    
    transactions.push({
      id: `trans-${i}-${Date.now()}`,
      type: sample.type as 'income' | 'expense',
      amount: Math.round(amountVariation),
      description: sample.description,
      category: sample.category,
      division: sample.division as 'office' | 'personal',
      accountId: sample.accountId,
      date: date.toISOString(),
      createdAt: date.toISOString(),
    });
  }

  return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const sampleTransactions: Transaction[] = generateSampleTransactions();

export const sampleTransfers: Transfer[] = [
  {
    id: 'transfer-1',
    fromAccountId: 'bank',
    toAccountId: 'cash',
    amount: 500,
    description: 'Weekly cash withdrawal',
    date: new Date().toISOString(),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'transfer-2',
    fromAccountId: 'bank',
    toAccountId: 'savings',
    amount: 2000,
    description: 'Monthly savings',
    date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  },
];
