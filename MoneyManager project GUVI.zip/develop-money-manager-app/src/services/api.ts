import { Transaction, Account, Transfer } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Helper function for API calls
async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const defaultOptions: RequestInit = {
    headers: {
      'Content-Type': 'application/json',
    },
  };

  const response = await fetch(url, { ...defaultOptions, ...options });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'API request failed');
  }

  return data;
}

// Transaction API
export const transactionApi = {
  // Get all transactions
  getAll: async (): Promise<Transaction[]> => {
    const response = await apiCall<{ success: boolean; data: Transaction[] }>('/transactions');
    return response.data;
  },

  // Get single transaction
  getById: async (id: string): Promise<Transaction> => {
    const response = await apiCall<{ success: boolean; data: Transaction }>(`/transactions/${id}`);
    return response.data;
  },

  // Create transaction
  create: async (transaction: Omit<Transaction, 'id' | 'createdAt'>): Promise<Transaction> => {
    const response = await apiCall<{ success: boolean; data: Transaction }>('/transactions', {
      method: 'POST',
      body: JSON.stringify(transaction),
    });
    return response.data;
  },

  // Update transaction
  update: async (id: string, transaction: Partial<Transaction>): Promise<Transaction> => {
    const response = await apiCall<{ success: boolean; data: Transaction }>(`/transactions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(transaction),
    });
    return response.data;
  },

  // Delete transaction
  delete: async (id: string): Promise<void> => {
    await apiCall<{ success: boolean }>(`/transactions/${id}`, {
      method: 'DELETE',
    });
  },

  // Filter transactions
  filter: async (params: {
    type?: string;
    category?: string;
    division?: string;
    accountId?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<Transaction[]> => {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value) queryParams.append(key, value);
    });
    
    const response = await apiCall<{ success: boolean; data: Transaction[] }>(
      `/transactions/filter?${queryParams.toString()}`
    );
    return response.data;
  },

  // Get category summary
  getSummary: async (startDate?: string, endDate?: string): Promise<any[]> => {
    const queryParams = new URLSearchParams();
    if (startDate) queryParams.append('startDate', startDate);
    if (endDate) queryParams.append('endDate', endDate);
    
    const response = await apiCall<{ success: boolean; data: any[] }>(
      `/transactions/summary?${queryParams.toString()}`
    );
    return response.data;
  },

  // Get dashboard stats
  getStats: async (period: 'weekly' | 'monthly' | 'yearly'): Promise<{
    income: number;
    expense: number;
    netBalance: number;
    categoryBreakdown: { category: string; amount: number }[];
  }> => {
    const response = await apiCall<{ success: boolean; data: any }>(
      `/transactions/stats?period=${period}`
    );
    return response.data;
  },
};

// Account API
export const accountApi = {
  // Get all accounts
  getAll: async (): Promise<Account[]> => {
    const response = await apiCall<{ success: boolean; data: Account[] }>('/accounts');
    return response.data.map(acc => ({
      ...acc,
      id: acc._id || acc.id,
    }));
  },

  // Get single account
  getById: async (id: string): Promise<Account> => {
    const response = await apiCall<{ success: boolean; data: Account }>(`/accounts/${id}`);
    return { ...response.data, id: response.data._id || response.data.id };
  },

  // Initialize default accounts
  initialize: async (): Promise<Account[]> => {
    const response = await apiCall<{ success: boolean; data: Account[] }>('/accounts/init', {
      method: 'POST',
    });
    return response.data;
  },

  // Get total balance
  getTotalBalance: async (): Promise<number> => {
    const response = await apiCall<{ success: boolean; data: { totalBalance: number } }>(
      '/accounts/total'
    );
    return response.data.totalBalance;
  },
};

// Transfer API
export const transferApi = {
  // Get all transfers
  getAll: async (): Promise<Transfer[]> => {
    const response = await apiCall<{ success: boolean; data: Transfer[] }>('/transfers');
    return response.data;
  },

  // Create transfer
  create: async (transfer: {
    fromAccountId: string;
    toAccountId: string;
    amount: number;
    description?: string;
  }): Promise<Transfer> => {
    const response = await apiCall<{ success: boolean; data: Transfer }>('/transfers', {
      method: 'POST',
      body: JSON.stringify(transfer),
    });
    return response.data;
  },

  // Get transfers by account
  getByAccount: async (accountId: string): Promise<Transfer[]> => {
    const response = await apiCall<{ success: boolean; data: Transfer[] }>(
      `/transfers/account/${accountId}`
    );
    return response.data;
  },

  // Filter transfers
  filter: async (params: {
    startDate?: string;
    endDate?: string;
    accountId?: string;
  }): Promise<Transfer[]> => {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value) queryParams.append(key, value);
    });
    
    const response = await apiCall<{ success: boolean; data: Transfer[] }>(
      `/transfers/filter?${queryParams.toString()}`
    );
    return response.data;
  },
};

// Health check
export const healthCheck = async (): Promise<boolean> => {
  try {
    await apiCall<{ success: boolean }>('/health');
    return true;
  } catch {
    return false;
  }
};

export default {
  transaction: transactionApi,
  account: accountApi,
  transfer: transferApi,
  healthCheck,
};
