import { useState } from 'react';
import {
  LayoutDashboard,
  Receipt,
  PieChart,
  ArrowLeftRight,
  Plus,
  Menu,
  Wallet,
  Database,
  HardDrive,
  Loader2,
} from 'lucide-react';
import { MoneyProvider, useMoneyContext } from './context/MoneyContext';
import { Dashboard } from './components/Dashboard';
import { TransactionList } from './components/TransactionList';
import { Summary } from './components/Summary';
import { AccountTransfer } from './components/AccountTransfer';
import { TransactionModal } from './components/TransactionModal';

type Tab = 'dashboard' | 'transactions' | 'summary' | 'transfers';

const tabs: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'transactions', label: 'Transactions', icon: Receipt },
  { id: 'summary', label: 'Summary', icon: PieChart },
  { id: 'transfers', label: 'Transfers', icon: ArrowLeftRight },
];

function AppContent() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { isLoading, isApiConnected } = useMoneyContext();

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex h-64 items-center justify-center">
          <div className="text-center">
            <Loader2 className="mx-auto h-12 w-12 animate-spin text-indigo-500" />
            <p className="mt-4 text-gray-500">Loading your financial data...</p>
          </div>
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'transactions':
        return <TransactionList />;
      case 'summary':
        return <Summary />;
      case 'transfers':
        return <AccountTransfer />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 transform bg-gradient-to-b from-indigo-900 via-indigo-800 to-indigo-900 transition-transform duration-300 lg:static lg:translate-x-0 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex items-center gap-3 px-6 py-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/20">
              <Wallet className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Money Manager</h1>
              <p className="text-xs text-indigo-300">Personal Finance</p>
            </div>
          </div>

          {/* Connection Status */}
          <div className="mx-4 mb-4 rounded-lg bg-white/10 px-4 py-2">
            <div className="flex items-center gap-2">
              {isApiConnected ? (
                <>
                  <Database className="h-4 w-4 text-green-400" />
                  <span className="text-xs text-green-300">MongoDB Connected</span>
                </>
              ) : (
                <>
                  <HardDrive className="h-4 w-4 text-yellow-400" />
                  <span className="text-xs text-yellow-300">Local Storage Mode</span>
                </>
              )}
            </div>
          </div>

          {/* Navigation */}
          <nav className="mt-2 flex-1 px-4">
            <ul className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <li key={tab.id}>
                    <button
                      onClick={() => {
                        setActiveTab(tab.id);
                        setIsSidebarOpen(false);
                      }}
                      className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left transition-all ${
                        isActive
                          ? 'bg-white/20 text-white shadow-lg'
                          : 'text-indigo-200 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="font-medium">{tab.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Add Button in Sidebar */}
          <div className="p-4">
            <button
              onClick={() => {
                setIsModalOpen(true);
                setIsSidebarOpen(false);
              }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 py-3 font-medium text-white shadow-lg transition-all hover:from-green-600 hover:to-emerald-700 hover:shadow-xl"
            >
              <Plus className="h-5 w-5" />
              Add Transaction
            </button>
          </div>

          {/* Footer */}
          <div className="border-t border-indigo-700 px-6 py-4">
            <p className="text-xs text-indigo-400">
              © 2026 Money Manager
            </p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-gray-200 bg-white px-4 py-4 shadow-sm lg:px-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 lg:hidden"
            >
              <Menu className="h-6 w-6" />
            </button>
            <h2 className="text-lg font-semibold text-gray-800 lg:text-xl">
              {tabs.find((t) => t.id === activeTab)?.label}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Connection Badge */}
            <div className={`hidden items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium sm:flex ${
              isApiConnected 
                ? 'bg-green-100 text-green-700' 
                : 'bg-yellow-100 text-yellow-700'
            }`}>
              {isApiConnected ? (
                <>
                  <Database className="h-3.5 w-3.5" />
                  MongoDB
                </>
              ) : (
                <>
                  <HardDrive className="h-3.5 w-3.5" />
                  Local
                </>
              )}
            </div>

            {/* Mobile Add Button */}
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 px-4 py-2 font-medium text-white shadow-md transition-all hover:shadow-lg lg:hidden"
            >
              <Plus className="h-5 w-5" />
            </button>

            {/* Desktop Add Button */}
            <button
              onClick={() => setIsModalOpen(true)}
              className="hidden items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 px-5 py-2.5 font-medium text-white shadow-md transition-all hover:shadow-lg lg:flex"
            >
              <Plus className="h-5 w-5" />
              Add Transaction
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-4 lg:p-8">{renderContent()}</div>
      </main>

      {/* Transaction Modal */}
      <TransactionModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />

      {/* Floating Add Button for Mobile */}
      <button
        onClick={() => setIsModalOpen(true)}
        className="fixed bottom-6 right-6 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg transition-all hover:shadow-xl lg:hidden"
      >
        <Plus className="h-6 w-6" />
      </button>
    </div>
  );
}

export function App() {
  return (
    <MoneyProvider>
      <AppContent />
    </MoneyProvider>
  );
}
