import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, isWithinInterval, differenceInHours, parseISO } from 'date-fns';
import { Transaction, ViewPeriod, CategorySummary } from '../types';

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatDate = (date: string | Date): string => {
  return format(new Date(date), 'MMM dd, yyyy');
};

export const formatDateTime = (date: string | Date): string => {
  return format(new Date(date), 'MMM dd, yyyy HH:mm');
};

export const getDateRange = (period: ViewPeriod, date: Date = new Date()) => {
  switch (period) {
    case 'weekly':
      return { start: startOfWeek(date), end: endOfWeek(date) };
    case 'monthly':
      return { start: startOfMonth(date), end: endOfMonth(date) };
    case 'yearly':
      return { start: startOfYear(date), end: endOfYear(date) };
  }
};

export const filterTransactionsByPeriod = (
  transactions: Transaction[],
  period: ViewPeriod,
  date: Date = new Date()
): Transaction[] => {
  const { start, end } = getDateRange(period, date);
  return transactions.filter((t) =>
    isWithinInterval(new Date(t.date), { start, end })
  );
};

export const filterTransactionsByDateRange = (
  transactions: Transaction[],
  startDate: string,
  endDate: string
): Transaction[] => {
  if (!startDate || !endDate) return transactions;
  return transactions.filter((t) =>
    isWithinInterval(new Date(t.date), {
      start: parseISO(startDate),
      end: parseISO(endDate),
    })
  );
};

export const canEditTransaction = (createdAt: string): boolean => {
  const hoursDiff = differenceInHours(new Date(), new Date(createdAt));
  return hoursDiff <= 12;
};

export const calculateTotals = (transactions: Transaction[]) => {
  return transactions.reduce(
    (acc, t) => {
      if (t.type === 'income') {
        acc.income += t.amount;
      } else {
        acc.expense += t.amount;
      }
      return acc;
    },
    { income: 0, expense: 0 }
  );
};

export const getCategorySummary = (transactions: Transaction[]): CategorySummary[] => {
  const summary: Record<string, CategorySummary> = {};
  
  transactions.forEach((t) => {
    if (!summary[t.category]) {
      summary[t.category] = { category: t.category, income: 0, expense: 0, count: 0 };
    }
    summary[t.category].count++;
    if (t.type === 'income') {
      summary[t.category].income += t.amount;
    } else {
      summary[t.category].expense += t.amount;
    }
  });

  return Object.values(summary).sort((a, b) => (b.income + b.expense) - (a.income + a.expense));
};

export const getChartData = (transactions: Transaction[], period: ViewPeriod) => {
  const groupedData: Record<string, { name: string; income: number; expense: number }> = {};
  
  transactions.forEach((t) => {
    let key: string;
    const date = new Date(t.date);
    
    switch (period) {
      case 'weekly':
        key = format(date, 'EEE');
        break;
      case 'monthly':
        key = format(date, 'dd');
        break;
      case 'yearly':
        key = format(date, 'MMM');
        break;
    }
    
    if (!groupedData[key]) {
      groupedData[key] = { name: key, income: 0, expense: 0 };
    }
    
    if (t.type === 'income') {
      groupedData[key].income += t.amount;
    } else {
      groupedData[key].expense += t.amount;
    }
  });

  return Object.values(groupedData);
};

export const generateId = (): string => {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};
