export type TransactionType = 'income' | 'expense';
export type Division = 'office' | 'personal';

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface Account {
  id: string;
  _id?: string;
  name: string;
  balance: number;
  icon?: string;
  color: string;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  description: string;
  category: string;
  division: Division;
  accountId: string;
  date: string;
  createdAt: string;
}

export interface Transfer {
  id: string;
  fromAccountId: string;
  toAccountId: string;
  amount: number;
  description: string;
  date: string;
  createdAt: string;
}

export interface FilterState {
  type: TransactionType | 'all';
  division: Division | 'all';
  category: string;
  startDate: string;
  endDate: string;
  accountId: string;
}

export interface CategorySummary {
  category: string;
  income: number;
  expense: number;
  count: number;
}

export type ViewPeriod = 'weekly' | 'monthly' | 'yearly';
