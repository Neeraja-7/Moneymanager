import { useState } from 'react';
import { ArrowRight, Send, History, Wallet } from 'lucide-react';
import { useMoneyContext } from '../context/MoneyContext';
import { formatCurrency, formatDateTime } from '../utils/helpers';

export function AccountTransfer() {
  const { accounts, transfers, addTransfer } = useMoneyContext();
  const [formData, setFormData] = useState({
    fromAccountId: '',
    toAccountId: '',
    amount: '',
    description: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!formData.fromAccountId || !formData.toAccountId || !formData.amount) {
      setError('Please fill in all required fields');
      return;
    }

    if (formData.fromAccountId === formData.toAccountId) {
      setError('Source and destination accounts must be different');
      return;
    }

    const amount = parseFloat(formData.amount);
    const fromAccount = accounts.find((a) => a.id === formData.fromAccountId);

    if (fromAccount && fromAccount.balance < amount) {
      setError('Insufficient balance in source account');
      return;
    }

    addTransfer({
      fromAccountId: formData.fromAccountId,
      toAccountId: formData.toAccountId,
      amount,
      description: formData.description || 'Transfer',
      date: new Date().toISOString(),
    });

    setSuccess('Transfer completed successfully!');
    setFormData({
      fromAccountId: '',
      toAccountId: '',
      amount: '',
      description: '',
    });

    setTimeout(() => setSuccess(''), 3000);
  };

  const getAccountName = (id: string) => {
    return accounts.find((a) => a.id === id)?.name || id;
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Account Transfers</h2>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Transfer Form */}
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <div className="mb-6 flex items-center gap-2">
            <Send className="h-5 w-5 text-indigo-500" />
            <h3 className="text-lg font-semibold text-gray-800">New Transfer</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="rounded-lg bg-red-50 p-3 text-sm text-red-600">{error}</div>
            )}
            {success && (
              <div className="rounded-lg bg-green-50 p-3 text-sm text-green-600">{success}</div>
            )}

            {/* From Account */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">From Account *</label>
              <select
                value={formData.fromAccountId}
                onChange={(e) => setFormData({ ...formData, fromAccountId: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="">Select source account</option>
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} ({formatCurrency(acc.balance)})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-center">
              <ArrowRight className="h-6 w-6 text-gray-400" />
            </div>

            {/* To Account */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">To Account *</label>
              <select
                value={formData.toAccountId}
                onChange={(e) => setFormData({ ...formData, toAccountId: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="">Select destination account</option>
                {accounts
                  .filter((acc) => acc.id !== formData.fromAccountId)
                  .map((acc) => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} ({formatCurrency(acc.balance)})
                    </option>
                  ))}
              </select>
            </div>

            {/* Amount */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Amount *</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full rounded-lg border border-gray-300 py-2.5 pl-8 pr-4 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  placeholder="0.00"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Description</label>
              <input
                type="text"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="Enter description (optional)"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-indigo-500 py-3 font-medium text-white transition-colors hover:bg-indigo-600"
            >
              Transfer Money
            </button>
          </form>
        </div>

        {/* Accounts Overview */}
        <div className="space-y-4">
          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="mb-4 flex items-center gap-2">
              <Wallet className="h-5 w-5 text-indigo-500" />
              <h3 className="text-lg font-semibold text-gray-800">Your Accounts</h3>
            </div>
            <div className="space-y-3">
              {accounts.map((account) => (
                <div
                  key={account.id}
                  className="flex items-center justify-between rounded-lg border border-gray-100 p-4 transition-shadow hover:shadow-md"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-full text-lg font-bold"
                      style={{ backgroundColor: account.color + '20', color: account.color }}
                    >
                      {account.name.charAt(0)}
                    </div>
                    <span className="font-medium text-gray-800">{account.name}</span>
                  </div>
                  <span
                    className={`text-lg font-bold ${
                      account.balance >= 0 ? 'text-gray-800' : 'text-red-600'
                    }`}
                  >
                    {formatCurrency(account.balance)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Transfer History */}
      <div className="rounded-xl bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center gap-2">
          <History className="h-5 w-5 text-indigo-500" />
          <h3 className="text-lg font-semibold text-gray-800">Transfer History</h3>
        </div>

        {transfers.length > 0 ? (
          <div className="divide-y divide-gray-50">
            {transfers.slice(0, 10).map((transfer) => (
              <div
                key={transfer.id}
                className="flex items-center justify-between py-4"
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-indigo-100">
                    <ArrowRight className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">
                      {getAccountName(transfer.fromAccountId)} → {getAccountName(transfer.toAccountId)}
                    </p>
                    <p className="text-sm text-gray-500">{transfer.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-800">{formatCurrency(transfer.amount)}</p>
                  <p className="text-xs text-gray-400">{formatDateTime(transfer.date)}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center text-gray-400">No transfers yet</div>
        )}
      </div>
    </div>
  );
}
