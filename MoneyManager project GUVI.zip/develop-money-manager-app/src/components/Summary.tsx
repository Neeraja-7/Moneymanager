import { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { TrendingUp, TrendingDown, BarChart3 } from 'lucide-react';
import { useMoneyContext } from '../context/MoneyContext';
import { getCategorySummary, formatCurrency, filterTransactionsByPeriod } from '../utils/helpers';

const COLORS = ['#22c55e', '#3b82f6', '#f97316', '#8b5cf6', '#ef4444', '#ec4899', '#14b8a6', '#f59e0b', '#6366f1', '#10b981'];

export function Summary() {
  const { transactions, categories, viewPeriod, selectedDate } = useMoneyContext();

  const filteredTransactions = useMemo(
    () => filterTransactionsByPeriod(transactions, viewPeriod, selectedDate),
    [transactions, viewPeriod, selectedDate]
  );

  const categorySummary = useMemo(
    () => getCategorySummary(filteredTransactions),
    [filteredTransactions]
  );

  const getCategoryInfo = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId) || { name: categoryId, icon: '📋', color: '#64748b' };
  };

  const incomeData = useMemo(
    () =>
      categorySummary
        .filter((c) => c.income > 0)
        .map((c) => ({ name: getCategoryInfo(c.category).name, value: c.income })),
    [categorySummary]
  );

  const expenseData = useMemo(
    () =>
      categorySummary
        .filter((c) => c.expense > 0)
        .map((c) => ({ name: getCategoryInfo(c.category).name, value: c.expense })),
    [categorySummary]
  );

  const totalIncome = useMemo(() => categorySummary.reduce((sum, c) => sum + c.income, 0), [categorySummary]);
  const totalExpense = useMemo(() => categorySummary.reduce((sum, c) => sum + c.expense, 0), [categorySummary]);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Category Summary</h2>

      {/* Pie Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Income by Category */}
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <div className="mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            <h3 className="text-lg font-semibold text-gray-800">Income by Category</h3>
          </div>
          <div className="h-64">
            {incomeData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={incomeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {incomeData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-gray-400">
                No income data
              </div>
            )}
          </div>
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500">Total Income</p>
            <p className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
          </div>
        </div>

        {/* Expense by Category */}
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <div className="mb-4 flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-red-500" />
            <h3 className="text-lg font-semibold text-gray-800">Expense by Category</h3>
          </div>
          <div className="h-64">
            {expenseData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={expenseData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {expenseData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-gray-400">
                No expense data
              </div>
            )}
          </div>
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500">Total Expense</p>
            <p className="text-2xl font-bold text-red-600">{formatCurrency(totalExpense)}</p>
          </div>
        </div>
      </div>

      {/* Category Breakdown Table */}
      <div className="rounded-xl bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-indigo-500" />
          <h3 className="text-lg font-semibold text-gray-800">Detailed Breakdown</h3>
        </div>
        
        {categorySummary.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 text-left text-sm text-gray-500">
                  <th className="pb-3 font-medium">Category</th>
                  <th className="pb-3 text-right font-medium">Income</th>
                  <th className="pb-3 text-right font-medium">Expense</th>
                  <th className="pb-3 text-right font-medium">Net</th>
                  <th className="pb-3 text-right font-medium">Transactions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {categorySummary.map((item) => {
                  const category = getCategoryInfo(item.category);
                  const net = item.income - item.expense;
                  
                  return (
                    <tr key={item.category} className="text-sm">
                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <span
                            className="flex h-8 w-8 items-center justify-center rounded-lg text-lg"
                            style={{ backgroundColor: category.color + '20' }}
                          >
                            {category.icon}
                          </span>
                          <span className="font-medium text-gray-800">{category.name}</span>
                        </div>
                      </td>
                      <td className="py-3 text-right text-green-600">
                        {item.income > 0 ? formatCurrency(item.income) : '-'}
                      </td>
                      <td className="py-3 text-right text-red-600">
                        {item.expense > 0 ? formatCurrency(item.expense) : '-'}
                      </td>
                      <td className={`py-3 text-right font-medium ${net >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(net)}
                      </td>
                      <td className="py-3 text-right text-gray-500">{item.count}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t border-gray-200 font-semibold">
                  <td className="pt-4 text-gray-800">Total</td>
                  <td className="pt-4 text-right text-green-600">{formatCurrency(totalIncome)}</td>
                  <td className="pt-4 text-right text-red-600">{formatCurrency(totalExpense)}</td>
                  <td className={`pt-4 text-right ${totalIncome - totalExpense >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {formatCurrency(totalIncome - totalExpense)}
                  </td>
                  <td className="pt-4 text-right text-gray-500">
                    {categorySummary.reduce((sum, c) => sum + c.count, 0)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          <div className="py-8 text-center text-gray-400">
            No transactions for this period
          </div>
        )}
      </div>
    </div>
  );
}
