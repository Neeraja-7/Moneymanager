import { useMemo, useState } from 'react';
import { Edit2, Trash2, ArrowUpCircle, ArrowDownCircle, Clock, AlertCircle } from 'lucide-react';
import { useMoneyContext } from '../context/MoneyContext';
import { Transaction } from '../types';
import { formatCurrency, formatDateTime, canEditTransaction, filterTransactionsByDateRange } from '../utils/helpers';
import { Filters } from './Filters';
import { TransactionModal } from './TransactionModal';

export function TransactionList() {
  const { transactions, categories, accounts, filter, deleteTransaction } = useMoneyContext();
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const filteredTransactions = useMemo(() => {
    let result = [...transactions];

    // Filter by type
    if (filter.type !== 'all') {
      result = result.filter((t) => t.type === filter.type);
    }

    // Filter by division
    if (filter.division !== 'all') {
      result = result.filter((t) => t.division === filter.division);
    }

    // Filter by category
    if (filter.category) {
      result = result.filter((t) => t.category === filter.category);
    }

    // Filter by account
    if (filter.accountId) {
      result = result.filter((t) => t.accountId === filter.accountId);
    }

    // Filter by date range
    if (filter.startDate && filter.endDate) {
      result = filterTransactionsByDateRange(result, filter.startDate, filter.endDate);
    }

    return result;
  }, [transactions, filter]);

  const getCategoryInfo = (categoryId: string) => {
    return categories.find((c) => c.id === categoryId) || { name: categoryId, icon: '📋', color: '#64748b' };
  };

  const getAccountName = (accountId: string) => {
    return accounts.find((a) => a.id === accountId)?.name || accountId;
  };

  const handleDelete = (id: string) => {
    deleteTransaction(id);
    setShowDeleteConfirm(null);
  };

  const groupedTransactions = useMemo(() => {
    const groups: Record<string, Transaction[]> = {};
    filteredTransactions.forEach((t) => {
      const date = new Date(t.date).toDateString();
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(t);
    });
    return groups;
  }, [filteredTransactions]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Transaction History</h2>
        <span className="rounded-full bg-indigo-100 px-3 py-1 text-sm font-medium text-indigo-600">
          {filteredTransactions.length} transactions
        </span>
      </div>

      <Filters />

      {Object.keys(groupedTransactions).length === 0 ? (
        <div className="rounded-xl bg-white p-12 text-center shadow-sm">
          <AlertCircle className="mx-auto h-12 w-12 text-gray-300" />
          <h3 className="mt-4 text-lg font-medium text-gray-600">No transactions found</h3>
          <p className="mt-2 text-sm text-gray-400">
            Try adjusting your filters or add a new transaction
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedTransactions).map(([date, trans]) => (
            <div key={date} className="rounded-xl bg-white shadow-sm">
              <div className="border-b border-gray-100 px-6 py-3">
                <h3 className="font-medium text-gray-600">{date}</h3>
              </div>
              <div className="divide-y divide-gray-50">
                {trans.map((transaction) => {
                  const category = getCategoryInfo(transaction.category);
                  const canEdit = canEditTransaction(transaction.createdAt);

                  return (
                    <div
                      key={transaction.id}
                      className="flex items-center gap-4 px-6 py-4 transition-colors hover:bg-gray-50"
                    >
                      {/* Icon */}
                      <div
                        className="flex h-12 w-12 items-center justify-center rounded-xl text-2xl"
                        style={{ backgroundColor: category.color + '20' }}
                      >
                        {category.icon}
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium text-gray-800 truncate">
                            {transaction.description}
                          </h4>
                          {transaction.type === 'income' ? (
                            <ArrowUpCircle className="h-4 w-4 flex-shrink-0 text-green-500" />
                          ) : (
                            <ArrowDownCircle className="h-4 w-4 flex-shrink-0 text-red-500" />
                          )}
                        </div>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-gray-500">
                          <span className="rounded-full bg-gray-100 px-2 py-0.5">
                            {category.name}
                          </span>
                          <span className={`rounded-full px-2 py-0.5 ${
                            transaction.division === 'office'
                              ? 'bg-blue-100 text-blue-600'
                              : 'bg-purple-100 text-purple-600'
                          }`}>
                            {transaction.division}
                          </span>
                          <span className="text-gray-400">
                            {getAccountName(transaction.accountId)}
                          </span>
                        </div>
                      </div>

                      {/* Amount & Time */}
                      <div className="text-right">
                        <p
                          className={`text-lg font-bold ${
                            transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}
                        >
                          {transaction.type === 'income' ? '+' : '-'}
                          {formatCurrency(transaction.amount)}
                        </p>
                        <p className="mt-1 flex items-center justify-end gap-1 text-xs text-gray-400">
                          <Clock className="h-3 w-3" />
                          {formatDateTime(transaction.date)}
                        </p>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        {canEdit ? (
                          <button
                            onClick={() => setEditingTransaction(transaction)}
                            className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-indigo-50 hover:text-indigo-600"
                            title="Edit transaction"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                        ) : (
                          <button
                            className="cursor-not-allowed rounded-lg p-2 text-gray-300"
                            title="Editing disabled (12-hour limit exceeded)"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                        )}
                        {showDeleteConfirm === transaction.id ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleDelete(transaction.id)}
                              className="rounded-lg bg-red-500 px-2 py-1 text-xs text-white hover:bg-red-600"
                            >
                              Confirm
                            </button>
                            <button
                              onClick={() => setShowDeleteConfirm(null)}
                              className="rounded-lg bg-gray-200 px-2 py-1 text-xs text-gray-600 hover:bg-gray-300"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setShowDeleteConfirm(transaction.id)}
                            className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-red-50 hover:text-red-600"
                            title="Delete transaction"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      <TransactionModal
        isOpen={!!editingTransaction}
        onClose={() => setEditingTransaction(null)}
        editTransaction={editingTransaction}
      />
    </div>
  );
}
