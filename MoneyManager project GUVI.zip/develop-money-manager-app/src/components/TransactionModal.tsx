import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useMoneyContext } from '../context/MoneyContext';
import { Transaction, TransactionType, Division } from '../types';
import { canEditTransaction } from '../utils/helpers';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editTransaction?: Transaction | null;
}

export function TransactionModal({ isOpen, onClose, editTransaction }: TransactionModalProps) {
  const { categories, accounts, addTransaction, updateTransaction } = useMoneyContext();
  const [activeTab, setActiveTab] = useState<TransactionType>('expense');
  const [formData, setFormData] = useState({
    amount: '',
    description: '',
    category: '',
    division: 'personal' as Division,
    accountId: '',
    date: new Date().toISOString().slice(0, 16),
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (editTransaction) {
      setActiveTab(editTransaction.type);
      setFormData({
        amount: editTransaction.amount.toString(),
        description: editTransaction.description,
        category: editTransaction.category,
        division: editTransaction.division,
        accountId: editTransaction.accountId,
        date: new Date(editTransaction.date).toISOString().slice(0, 16),
      });
    } else {
      setFormData({
        amount: '',
        description: '',
        category: '',
        division: 'personal',
        accountId: accounts[0]?.id || '',
        date: new Date().toISOString().slice(0, 16),
      });
    }
  }, [editTransaction, accounts, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!formData.amount || !formData.description || !formData.category || !formData.accountId) {
      setError('Please fill in all required fields');
      return;
    }

    const transactionData = {
      type: activeTab,
      amount: parseFloat(formData.amount),
      description: formData.description,
      category: formData.category,
      division: formData.division,
      accountId: formData.accountId,
      date: new Date(formData.date).toISOString(),
    };

    if (editTransaction) {
      if (!canEditTransaction(editTransaction.createdAt)) {
        setError('This transaction can no longer be edited (12-hour limit exceeded)');
        return;
      }
      updateTransaction(editTransaction.id, transactionData);
    } else {
      addTransaction(transactionData);
    }

    onClose();
  };

  if (!isOpen) return null;

  const incomeCategories = categories.filter((c) =>
    ['salary', 'freelance', 'investment', 'gift', 'other'].includes(c.id)
  );
  const expenseCategories = categories.filter(
    (c) => !['salary', 'freelance', 'investment'].includes(c.id)
  );

  const relevantCategories = activeTab === 'income' ? incomeCategories : expenseCategories;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-100 px-6 py-4">
          <h2 className="text-xl font-bold text-gray-800">
            {editTransaction ? 'Edit Transaction' : 'Add Transaction'}
          </h2>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-gray-400 transition-colors hover:bg-gray-100 hover:text-gray-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100">
          <button
            onClick={() => setActiveTab('income')}
            className={`flex-1 py-3 text-center font-medium transition-colors ${
              activeTab === 'income'
                ? 'border-b-2 border-green-500 text-green-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Income
          </button>
          <button
            onClick={() => setActiveTab('expense')}
            className={`flex-1 py-3 text-center font-medium transition-colors ${
              activeTab === 'expense'
                ? 'border-b-2 border-red-500 text-red-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            Expense
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-600">{error}</div>
          )}

          <div className="space-y-4">
            {/* Amount */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Amount *</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full rounded-lg border border-gray-300 py-2.5 pl-8 pr-4 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  placeholder="0.00"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Description *</label>
              <input
                type="text"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
                placeholder="Enter description"
              />
            </div>

            {/* Category */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Category *</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="">Select category</option>
                {relevantCategories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.icon} {cat.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Division */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Division</label>
              <div className="flex gap-4">
                <label className="flex cursor-pointer items-center gap-2">
                  <input
                    type="radio"
                    name="division"
                    value="personal"
                    checked={formData.division === 'personal'}
                    onChange={(e) => setFormData({ ...formData, division: e.target.value as Division })}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm text-gray-700">Personal</span>
                </label>
                <label className="flex cursor-pointer items-center gap-2">
                  <input
                    type="radio"
                    name="division"
                    value="office"
                    checked={formData.division === 'office'}
                    onChange={(e) => setFormData({ ...formData, division: e.target.value as Division })}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-sm text-gray-700">Office</span>
                </label>
              </div>
            </div>

            {/* Account */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Account *</label>
              <select
                value={formData.accountId}
                onChange={(e) => setFormData({ ...formData, accountId: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              >
                <option value="">Select account</option>
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Date & Time */}
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">Date & Time</label>
              <input
                type="datetime-local"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-200"
              />
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className={`mt-6 w-full rounded-lg py-3 font-medium text-white transition-colors ${
              activeTab === 'income'
                ? 'bg-green-500 hover:bg-green-600'
                : 'bg-red-500 hover:bg-red-600'
            }`}
          >
            {editTransaction ? 'Update' : 'Add'} {activeTab === 'income' ? 'Income' : 'Expense'}
          </button>
        </form>
      </div>
    </div>
  );
}
