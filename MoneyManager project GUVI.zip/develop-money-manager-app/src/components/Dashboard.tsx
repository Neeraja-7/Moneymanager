import { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Wallet, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { useMoneyContext } from '../context/MoneyContext';
import { filterTransactionsByPeriod, calculateTotals, formatCurrency, getChartData, getCategorySummary } from '../utils/helpers';
import { ViewPeriod } from '../types';

const COLORS = ['#22c55e', '#3b82f6', '#f97316', '#8b5cf6', '#ef4444', '#ec4899', '#14b8a6', '#f59e0b'];

export function Dashboard() {
  const { transactions, accounts, viewPeriod, setViewPeriod, selectedDate } = useMoneyContext();

  const filteredTransactions = useMemo(
    () => filterTransactionsByPeriod(transactions, viewPeriod, selectedDate),
    [transactions, viewPeriod, selectedDate]
  );

  const { income, expense } = useMemo(
    () => calculateTotals(filteredTransactions),
    [filteredTransactions]
  );

  const chartData = useMemo(
    () => getChartData(filteredTransactions, viewPeriod),
    [filteredTransactions, viewPeriod]
  );

  const categorySummary = useMemo(
    () => getCategorySummary(filteredTransactions),
    [filteredTransactions]
  );

  const pieData = useMemo(
    () =>
      categorySummary
        .filter((c) => c.expense > 0)
        .slice(0, 8)
        .map((c) => ({ name: c.category, value: c.expense })),
    [categorySummary]
  );

  const totalBalance = useMemo(
    () => accounts.reduce((sum, acc) => sum + acc.balance, 0),
    [accounts]
  );

  const balance = income - expense;

  const periodLabels: Record<ViewPeriod, string> = {
    weekly: 'This Week',
    monthly: 'This Month',
    yearly: 'This Year',
  };

  return (
    <div className="space-y-6">
      {/* Period Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
        <div className="flex rounded-lg bg-gray-100 p-1">
          {(['weekly', 'monthly', 'yearly'] as ViewPeriod[]).map((period) => (
            <button
              key={period}
              onClick={() => setViewPeriod(period)}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-all ${
                viewPeriod === period
                  ? 'bg-white text-indigo-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              {period.charAt(0).toUpperCase() + period.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 p-6 text-white shadow-lg shadow-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-100">Total Income</p>
              <p className="mt-1 text-2xl font-bold">{formatCurrency(income)}</p>
              <p className="mt-2 text-xs text-green-100">{periodLabels[viewPeriod]}</p>
            </div>
            <div className="rounded-full bg-white/20 p-3">
              <TrendingUp className="h-6 w-6" />
            </div>
          </div>
        </div>

        <div className="rounded-xl bg-gradient-to-br from-red-500 to-rose-600 p-6 text-white shadow-lg shadow-red-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-100">Total Expense</p>
              <p className="mt-1 text-2xl font-bold">{formatCurrency(expense)}</p>
              <p className="mt-2 text-xs text-red-100">{periodLabels[viewPeriod]}</p>
            </div>
            <div className="rounded-full bg-white/20 p-3">
              <TrendingDown className="h-6 w-6" />
            </div>
          </div>
        </div>

        <div className={`rounded-xl bg-gradient-to-br p-6 text-white shadow-lg ${
          balance >= 0 
            ? 'from-blue-500 to-indigo-600 shadow-blue-200' 
            : 'from-orange-500 to-amber-600 shadow-orange-200'
        }`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium opacity-90">Net Balance</p>
              <p className="mt-1 text-2xl font-bold">{formatCurrency(balance)}</p>
              <p className="mt-2 flex items-center text-xs opacity-90">
                {balance >= 0 ? (
                  <><ArrowUpRight className="mr-1 h-3 w-3" /> Surplus</>
                ) : (
                  <><ArrowDownRight className="mr-1 h-3 w-3" /> Deficit</>
                )}
              </p>
            </div>
            <div className="rounded-full bg-white/20 p-3">
              <Wallet className="h-6 w-6" />
            </div>
          </div>
        </div>

        <div className="rounded-xl bg-gradient-to-br from-purple-500 to-violet-600 p-6 text-white shadow-lg shadow-purple-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-100">Total Assets</p>
              <p className="mt-1 text-2xl font-bold">{formatCurrency(totalBalance)}</p>
              <p className="mt-2 text-xs text-purple-100">{accounts.length} Accounts</p>
            </div>
            <div className="rounded-full bg-white/20 p-3">
              <Wallet className="h-6 w-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Bar Chart */}
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <h3 className="mb-4 text-lg font-semibold text-gray-800">Income vs Expense</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#9ca3af" />
                <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
                <Tooltip
                  formatter={(value) => formatCurrency(Number(value))}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="income" name="Income" fill="#22c55e" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expense" name="Expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart */}
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <h3 className="mb-4 text-lg font-semibold text-gray-800">Expense by Category</h3>
          <div className="h-72">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {pieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value) => formatCurrency(Number(value))}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-gray-400">
                No expense data for this period
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Accounts Overview */}
      <div className="rounded-xl bg-white p-6 shadow-sm">
        <h3 className="mb-4 text-lg font-semibold text-gray-800">Accounts Overview</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {accounts.map((account) => (
            <div
              key={account.id}
              className="rounded-lg border border-gray-100 p-4 transition-shadow hover:shadow-md"
            >
              <div className="flex items-center gap-3">
                <div
                  className="h-10 w-10 rounded-full"
                  style={{ backgroundColor: account.color + '20' }}
                >
                  <div
                    className="flex h-full w-full items-center justify-center rounded-full text-lg font-bold"
                    style={{ color: account.color }}
                  >
                    {account.name.charAt(0)}
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-500">{account.name}</p>
                  <p
                    className={`text-lg font-bold ${
                      account.balance >= 0 ? 'text-gray-800' : 'text-red-600'
                    }`}
                  >
                    {formatCurrency(account.balance)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
